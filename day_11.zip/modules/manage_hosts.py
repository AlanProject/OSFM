#!/usr/bin/env python
#-*- coding:utf-8 -*-
from modules conn_mysql
class manage_hosts(object):
    #group
    def group_add(self):
        pass
    def group_del(self):
        pass
    def group_fetch(self):
        pass
    #host
    def host_add(self):
        pass
    def host_del(self):
        pass
    def host_fetch(self):
        pass