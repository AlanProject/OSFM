#!/usr/bin/env python
#-*- coding:utf-8 -*-
import os,sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from bin import OSFM_main
if __name__ == '__main__':
    inport = OSFM_main.OSFM_main()